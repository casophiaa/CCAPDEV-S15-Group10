const Post = require('../models/PostModel');
const Comment = require('../models/CommentModel');

const viewPostController = {
    viewPost: async function(req, res) {
        try {
            const postId = req.params.id; // Assuming the post ID is passed in the URL
            const post = await Post.findById(postId).exec();
            const comments = await Comment.find({ post: postId }).exec();

            // Render the hbs template with the post and comments data    <--- IDK HOW TO MAKE IT GENERAL FOR ALL HBS BUT STILL ONLY GET THE SPECIFC (PRE-ENLIST/ENLIST) PAGE
            res.render('pre-enlist1', { post: post, comments: comments });
        } catch (error) {
            console.error("Error retrieving post and comments:", error);
            res.status(500).send("Internal Server Error");
        }
    }
};

module.exports = viewPostController;
