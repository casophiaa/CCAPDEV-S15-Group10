const Announcement = require('../models/Announcement.js');

// Define the controller function
const announcementController = {
    getAnnouncement: function(req, res) {
        try {
            // Assuming announcement data is stored in a variable in index.js
            const announcementData = require('../index.js');

            // Render the announcement view with the announcement data
            res.render('announcement', { announcement: announcementData });
        } catch (err) {
            // Handle errors
            console.error('Error fetching announcement:', err);
            // Render an error page or redirect to another route
            res.status(500).send('Internal Server Error');
        }
    }
};

// Export the controller function
module.exports = announcementController;
