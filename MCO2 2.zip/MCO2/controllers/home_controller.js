const db = require('../models/db.js');
const User = require('../models/UserModel.js');
const Post = require('../models/PostModel.js');
const Comment = require('../models/CommentModel.js');

const homeController = {
    getHome: async function(req, res) {
        var details = {};
        var posts = await db.findMany(Post, {});
        
        // Check if req.session exists before setting properties
        if (req.session) {
            req.session.prev_page = 'home';
            
            if (req.session.flag) {
                details.flag = true;
                details.user = true;
                data = {
                    userName: req.session.user.userName,
                    firstName: req.session.user.firstName,
                    lastName: req.session.user.lastName,
                };
                posts.forEach(function(post) {
                    post.flag = req.session.flag;
                });
                console.log(posts);
                details.posts = posts;
                details.data = data;
            } else {
                details.flag = false;
            }
        } else {
            // Handle the case where req.session is not defined
            console.error("req.session is undefined");
        }
        
        res.render('home', details);
    },
};
module.exports = homeController;