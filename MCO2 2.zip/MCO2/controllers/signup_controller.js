const db = require("../models/db.js");
const User = require("../models/UserModel.js");

const signupController = {
  getSignUp: function (req, res) {
    res.render("signup");
  },

  postSignUp: async function (req, res) {
    var email = req.body.email;
    var lastName = req.body.lastName;
    var firstName = req.body.firstName;
    var username = req.body.username;
    var password = req.body.password;

    var user = {
      email: email,
      lastName: lastName,
      firstName: firstName,
      userName: username,
      password: password,
      contactNumber: "",
      idNumber: "",
    };

    var response = await db.insertOne(User, user);

    if (response != null) {
      req.session.flag = true;
      data = {
        userName: username,
        firstName: firstName,
        lastName: lastName,
      };
      req.session.user = data;
      res.redirect("/profile_page?userName=" + username);
    } else {
      res.render("register");
      req.session.flag = false;
    }
  },

  getCheckUsername: async function (req, res) {
    var username = req.query.username;
    var query = { username: username };
    var projection = "username";
    var result = await db.findOne(User, query, projection);
    if (result != null) {
      res.send(result);
    } else {
      res.send("");
    }
  },

  getCheckEmail: async function (req, res) {
    var email = req.query.email;
    var query = { email: email };
    var projection = "email";
    var result = await db.findOne(User, query, projection);
    if (result != null) {
      res.send(result);
    } else {
      res.send("");
    }
  },

  getCheckIdNumber: async function (req, res) {
    var idNumber = req.query.idNumber;
    var query = { idNumber: idNumber };
    var projection = "idNumber";
    var result = await db.findOne(User, query, projection);
    if (result != null) {
      res.send(result);
    } else {
      res.send("");
    }
  },
};

module.exports = signupController;
