var mongoose = require('mongoose');

var AnnouncementSchema = mongoose.Schema({
  username:{
    type:String,
    require:true
  },
  Title:{
    type:String,
    required: true
  },
  Description:{
    type:String, 
    required:true
  }
});

module.exports = mongoose.model('Announcement', AnnouncementSchema);