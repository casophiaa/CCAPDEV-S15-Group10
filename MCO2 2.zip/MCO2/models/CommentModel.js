var mongoose = require("mongoose");

var CommentSchema = new mongoose.Schema({
  author: {
    type: String,
    require: true,
  },
  post:{
    type:String,
    require:true
  },
  date:{
      type: Date,
      required: true
  },
  content:{
      type: String,
      required: true
  }
});

module.exports = mongoose.model('Comment', CommentSchema);