var mongoose = require("mongoose");

var UserSchema = new mongoose.Schema({
  email: {
    type: String,
    require: true,
  },
  lastName: {
    type: String,
    require: true,
  },
  firstName: {
    type: String,
    require: true,
  },
  userName: {
    type: String,
    require: true,
    unique: true,
  },
  password: {
    type: String,
    require: true,
  },
  isAdmin: {
    type: Boolean,
    require: true,
  },
  isLoggedIn: {
    type: Boolean,
    require: true,
  },
});

module.exports = mongoose.model("User", UserSchema);
