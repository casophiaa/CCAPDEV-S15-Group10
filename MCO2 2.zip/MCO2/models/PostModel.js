var mongoose = require('mongoose');

var PostSchema = new mongoose.Schema({
    username:{
        type : String,
        require : true
    },
    postTitle:{
        type: String,
        required : true
    },
    postContent:{
        type: String,
        required: true
    },
    postTag:{
        type: String,
        require: true
    },
    upvotes:{
        type: Array,
        required: false
    },
    downvotes:{
        type: Array,
        required: false
    },
  
    comments:{
      type: Array,
      required: false
    },

    shares:{
        type: Array,
        required: true
    }
});

module.exports = mongoose.model('Post', PostSchema);