const express = require("express");
const controller = require("../controllers/controller.js");
const signupController = require("../controllers/signup_controller.js");
const homeController = require("../controllers/home_controller.js");
//const loginController = require("../controllers/login_controller.js");
const preEnlistController = require("../controllers/preEnlist_controller.js");
const postController = require("../controllers/post_controller.js");

const app = express();

app.get("/", controller.getIndex);
app.get("/home",homeController.getHome);

app.get("/signup", signupController.getSignUp);

app.post("/signup", signupController.postSignUp); //form id in register.hbs should be signup

//app.post("/login", loginController.get)

app.get("/checkUsername", signupController.getCheckUsername);
app.get("/checkEmail", signupController.getCheckEmail);
app.get("/checkIdNumber", signupController.getCheckIdNumber);

app.get("/pre-enlist", preEnlistController.getPreEnlist);

app.get("/pre-enlist1", postController.viewPost);

app.get("/logout", controller.getLogout);
module.exports = app;
