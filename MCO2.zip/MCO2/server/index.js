const express = require('express');
const mongoose = require('mongoose');

const app = express();

mongoose.connect('mongodb://localhost:27017/MCO');

const userSchema = new mongoose.Schema({
    email: String,
    lastName: String,
    firstName: String,
    username: { type: String, unique: true },
    password: String
});

const UserModel = mongoose.model("users", userSchema); // Changed collection name to singular "User"

// Middleware to serve static files
const htmlFilesPath = 'C:/Users/Justin Sacdalan/Documents/College Files/2nd Year/2nd Sem/CCAPDEV MCO/MCO2';
app.use(express.static(htmlFilesPath));

// Middleware to parse JSON request bodies
app.use(express.json());

// Route to handle user signup
app.post("/signup", (req, res) => {
    // Retrieve user input from request body
    const { email, lastName, firstName, username, password } = req.body;

    // Check if username already exists in the database
    UserModel.findOne({ username: username }).then(existingUser => {
        if (existingUser) {
            // If the username exists, send an error response
            return res.status(400).json({ message: "Username already taken!" });
        } else {
            // Create a new user document
            const newUser = new UserModel({
                email: email,
                lastName: lastName,
                firstName: firstName,
                username: username,
                password: password
            });

            // Save the new user document to the database
            newUser.save().then(savedUser => {
                // Reset the form
                res.status(201).json({ message: "Account created successfully!", user: savedUser });
            }).catch(err => {
                console.error(err);
                res.status(500).json({ message: "Internal server error" });
            });
        }
    }).catch(err => {
        console.error(err);
        res.status(500).json({ message: "Internal server error" });
    });
});


// Route to handle user login
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    // Find the user with the provided username
    UserModel.findOne({ username: username }).then(user => {
        if (!user) {
            // If the user is not found, send an error response
            return res.status(404).json({ message: "Username not found. Please sign up." });
        }

        // Check if the provided password matches the user's password
        if (user.password === password) {
            // If the password is correct, send a success response
            return res.json({ message: "Login successful!", loggedInUser: username });
        } else {
            // If the password is incorrect, send an error response
            return res.status(401).json({ message: "Incorrect username or password." });
        }
    }).catch(err => {
        // If an error occurs, send an error response
        console.error(err);
        return res.status(500).json({ message: "Internal server error" });
    });
});

app.listen(3000, () => {
    console.log("Server is running");
});
