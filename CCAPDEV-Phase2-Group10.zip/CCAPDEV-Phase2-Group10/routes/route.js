const express = require('express');
const postController = require('../controllers/postController');

const app = express();

// HOME/INDEX
app.get('/', (req, res) => {
    res.render('index');
});

// LOGIN
app.get('/login', (req, res) => {
    res.render('login');
});

// SIGNUP
app.get('/signup', (req, res) => {
    res.render('signup');
});

// PRE-ENLIST
app.get('/pre-enlist', postController.getPreEnlistPosts);

// ENLIST
app.get('/enlistment', postController.getEnlistPosts);

// STU-CO
app.get('/student-concerns', postController.getConcernPosts);

app.get('/create-post', (req, res) => {
    res.render('create-post');
})

// ABOUT
app.get("/about", (req, res) => {
    res.render('about'); 
});

//CONTACT
app.get("/contact", (req, res) => {
    res.render('contact');
});

//PROFILE
app.get("/profile", (req, res) => {
    res.render('profile');                
});

module.exports = app;