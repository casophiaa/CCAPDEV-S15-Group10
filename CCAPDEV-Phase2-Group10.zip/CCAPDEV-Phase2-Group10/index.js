const express = require('express');
const mongoose = require('mongoose');
const exphbs = require('express-handlebars');
const userRoutes = require('./routes/userRoutes');
const postRoutes = require('./routes/postRoutes');
const routes = require('./routes/route');
const postController = require('./controllers/postController');

const app = express();

mongoose.connect('mongodb://localhost:27017/MCO');

// Create an instance of express-handlebars
const hbs = exphbs.create({ 
    extname: '.hbs',
    layoutsDir: __dirname + '/views/layouts/', // Set the layouts directory
    defaultLayout: false, // Disable default layout
    runtimeOptions: {
        allowProtoPropertiesByDefault: true
    }
});

// Set Handlebars as the view engine
app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');

// Middleware to parse JSON request bodies
app.use(express.json());

// Serve static files
app.use(express.static('public'));

// Middleware to parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));

// USER ROUTES FOR SIGNUP/LOGIN
app.use('/', userRoutes);

app.use('/', postRoutes);

app.use('/', routes);

// LISTENING ON PORT 3000
app.listen(3000, () => {
    console.log("Server is running");
});
