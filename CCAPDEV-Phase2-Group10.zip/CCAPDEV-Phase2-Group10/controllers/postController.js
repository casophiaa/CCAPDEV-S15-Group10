const PostModel = require("../models/postModel");
const CommentModel = require("../models/commentModel");

//PRE-ENLISTMENT
exports.createPreEnlistPost = (req, res) => {
  const newPost = new PostModel(req.body);
  console.log(req.body);
  newPost
    .save()
    .then(() => res.redirect("/pre-enlist"))
    .catch((err) => res.status(400).send("Unable to save to database"));
};

exports.getPreEnlistPosts = (req, res) => {
  PostModel.find({ postTag: "Pre-Enlistment" })
    .then((posts) => res.render("pre-enlist", { posts: posts }))
    .catch((err) => res.status(500).send("Error getting posts"));
};

//ENLISTMENT
exports.createEnlistPost = (req, res) => {
  const newPost = new PostModel(req.body);
  console.log(req.body);
  newPost
    .save()
    .then(() => res.redirect("/enlistment"))
    .catch((err) => res.status(400).send("Unable to save to database"));
};

exports.getEnlistPosts = (req, res) => {
  PostModel.find({ postTag: "Enlistment" })
    .then((posts) => res.render("enlistment", { posts: posts }))
    .catch((err) => res.status(500).send("Error getting posts"));
};

//STUDENT CONCERNS
exports.createConcernPost = (req, res) => {
  const newPost = new PostModel(req.body);
  console.log(req.body);
  newPost
    .save()
    .then(() => res.redirect("/student-concerns"))
    .catch((err) => res.status(400).send("Unable to save to database"));
};

exports.getConcernPosts = (req, res) => {
  PostModel.find({ postTag: "Student Concerns" })
    .then((posts) => res.render("student-concerns", { posts: posts }))
    .catch((err) => res.status(500).send("Error getting posts"));
};

// View Specific Post
exports.getPostById = (req, res) => {
  const postId = req.params.id;
  PostModel.findById(postId)
    .populate("comments")
    .then((post) => res.render("post", { post: post }))
    .catch((err) => {
      console.error(err);
      res.status(500).send("Error getting post");
    });
};

// Add Comments
exports.addComment = (req, res) => {
  // Create a new Comment
  const newComment = new CommentModel({
    username: "Anonymous", // Use a default username
    text: req.body.text, // Make sure req.body.text is defined
  });

  newComment
    .save()
    .then((comment) => {
      // Find the Post by ID and add the Comment's ObjectId to the Post's comments array
      return PostModel.findByIdAndUpdate(
        req.params.id,
        { $push: { comments: comment._id } },
        { new: true },
      );
    })
    .then((post) => {
      // Send the updated Post as the response
      res.json(post);
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send("Error adding comment");
    });
};
