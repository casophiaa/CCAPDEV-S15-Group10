const UserModel = require('../models/userModel');

exports.signup = async (req, res) => {
    const { email, lastName, firstName, username, password } = req.body;
    console.log(req.body);

    if (!email || !lastName || !firstName || !username || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    if (!username) {
        return res.status(400).json({ message: "Username is required" });
    }

    UserModel.findOne({ username: username }).then(existingUser => {
        if (existingUser) {
            return res.status(400).json({ message: "Username already taken" });
        } else {

            const newUser = new UserModel({
                email: email,
                lastName: lastName,
                firstName: firstName,
                username: username,
                password: password
            });

            console.log(username);

            newUser.save().then(savedUser => {
                res.status(201).json({ message: "Account created successfully!", user: savedUser });
            }).catch(err => {
                console.error("Error saving user:", err);
                res.status(500).json({ message: "Internal server error" });
            });
        }
    }).catch(err => {
        console.error("Error finding user:", err);
        res.status(500).json({ message: "Internal server error" });
    });
};

// Controller function to handle user login
exports.login = (req, res) => {
    const { username, password } = req.body;

    // Find the user with the provided username
    UserModel.findOne({ username: username }).then(user => {
        if (!user) {
            return res.status(404).json({ message: "Username not found. Please sign up." });
        }

        // Check if the provided password matches the user's password
        if (user.password === password) {
            return res.json({ message: "Login successful!", loggedInUser: username });
        } else {
            return res.status(401).json({ message: "Incorrect username or password." });
        }
    }).catch(err => {
        console.error("Error finding user:", err);
        res.status(500).json({ message: "Internal server error" });
    });
};
