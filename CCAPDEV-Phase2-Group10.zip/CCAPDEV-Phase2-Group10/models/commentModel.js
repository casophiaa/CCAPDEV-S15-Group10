var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var CommentSchema = new Schema({
  username: {
    type: String,
    required: true,
    default: "Anonymous",
  },
  text: {
    type: String,
    required: true,
  },
});

module.exports = mongoose.model("Comment", CommentSchema);
